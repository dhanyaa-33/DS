/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <math.h>
int isArmstrong(int n) 
{
    int num = n;
    int digits = 0;
    int sum = 0;
    while (num > 0) 
    {
        digits++;
        num /= 10;
    }
    num = n;
    while (num > 0) 
    {
        int digit = num % 10;
        sum += pow(digit, digits);
        num /= 10;
    }
    return (sum == n);
}

int main() 
{
    int n;
    printf("Enter a number: ");
    scanf("%d", &n);
    if (isArmstrong(n)) 
    {
        printf("%d is an Armstrong number\n", n);
    } 
    else 
    {
        printf("%d is not an Armstrong number\n", n);
    }
    return 0;
}
