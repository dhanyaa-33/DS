/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include<stdio.h>
 int main()
 {
     int num1, num2, i,lcm,hcf;

     printf("Enter two numbers: ");
     scanf("%d %d", &num1, &num2);

     for(i=1; i<=num1 && i<=num2; i++)
     {
         if(num1%i==0 && num2%i==0)
         {
             hcf=i;
         }
     }

     lcm=(num1*num2)/hcf;

     printf("HCF = %d\n",hcf);
     printf("LCM = %d\n",lcm);

     return 0;
 }
