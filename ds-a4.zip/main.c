/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
int main() 
{
    int n, i, even_sum = 0, odd_sum = 0;
    printf("Enter the number of elements in the array: ");
    scanf("%d", &n);
    int arr[n];
    printf("Enter the elements of the array:\n");
    for (i = 0; i < n; i++) 
    {
        scanf("%d", &arr[i]);
    }
    for (i = 0; i < n; i++)
    {
        if (arr[i] % 2 == 0) 
        {
            even_sum += arr[i];
        } 
        else 
        {
            odd_sum += arr[i];
        }
    }
    printf("The sum of even numbers %d \n", even_sum);
    printf("The sum of odd numbers %d \n", odd_sum);
    if (even_sum > odd_sum) 
    {
        printf("The sum of even numbers (%d) is greater than the sum of odd numbers (%d)\n", even_sum, odd_sum);
    } else if (odd_sum > even_sum) 
    {
        printf("The sum of odd numbers (%d) is greater than the sum of even numbers (%d)\n", odd_sum, even_sum);
    } else {
        printf("The sum of even numbers (%d) is equal to the sum of odd numbers (%d)\n", even_sum, odd_sum);
    }
    return 0;
}
